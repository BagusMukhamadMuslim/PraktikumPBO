/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Soal;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Buku implements Serializable {

    private String judul;
    private String pengarang;
    private int tahunTerbit;

    public Buku(String judul, String pengarang, int tahunTerbit) {
        this.judul = judul;
        this.pengarang = pengarang;
        this.tahunTerbit = tahunTerbit;
    }

    @Override
    public String toString() {
        return judul + ";" + pengarang + ";" + tahunTerbit;
    }

    public void tampilkanInfo() {
        System.out.println("Judul       : " + judul);
        System.out.println("Pengarang   : " + pengarang);
        System.out.println("Tahun Terbit: " + tahunTerbit);
    }
}


class ManajemenBuku {

    private static final String TEXT_FILE = "buku.txt";
    private static final String SERIAL_FILE = "buku.ser";
    private static List<Buku> daftarBuku = new ArrayList<>();

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nMenu Sistem");
            System.out.println("1. Tambah Buku Baru");
            System.out.println("2. Simpan ke File Teks (buku.txt)");
            System.out.println("3. Simpan Objek Buku (buku.ser)");
            System.out.println("4. Tampilkan Isi File buku.txt");
            System.out.println("5. Tampilkan Isi File buku.ser");
            System.out.println("6. Keluar");
            System.out.print("Pilihan: ");
            int pilihan = sc.nextInt();
            sc.nextLine();

            switch (pilihan) {
                case 1 -> tambahBuku(sc);
                case 2 -> simpanKeFileTeks();
                case 3 -> simpanKeFileSerial();
                case 4 -> tampilkanFileTeks();
                case 5 -> tampilkanFileSerial();
                case 6 -> {
                    System.out.println("Keluar...");
                    return;
                }
                default -> System.out.println("Pilihan tidak valid.");
            }
        }
    }

    private static void tambahBuku(Scanner sc) {
        System.out.print("Masukkan judul buku     : ");
        String judul = sc.nextLine();

        System.out.print("Masukkan nama pengarang : ");
        String pengarang = sc.nextLine();

        System.out.print("Masukkan tahun terbit   : ");
        int tahun = sc.nextInt();

        daftarBuku.add(new Buku(judul, pengarang, tahun));
        System.out.println("Buku berhasil ditambahkan!");
    }

    private static void simpanKeFileTeks() {
        try (FileWriter fw = new FileWriter(TEXT_FILE)) {
            for (Buku b : daftarBuku) {
                fw.write(b.toString() + "\n");
            }
            System.out.println("Data berhasil disimpan ke " + TEXT_FILE);
        } catch (IOException e) {
            System.out.println("Gagal menyimpan ke file teks.");
        }
    }

    private static void simpanKeFileSerial() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(SERIAL_FILE))) {
            oos.writeObject(daftarBuku);
            System.out.println("Objek berhasil disimpan ke " + SERIAL_FILE);
        } catch (IOException e) {
            System.out.println("Gagal serialisasi objek.");
        }
    }

    private static void tampilkanFileTeks() {
        System.out.println("\nDaftar Buku (TXT)");

        try (BufferedReader br = new BufferedReader(new FileReader(TEXT_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] d = line.split(";");
                Buku b = new Buku(d[0], d[1], Integer.parseInt(d[2]));
                b.tampilkanInfo();
            }
        } catch (IOException e) {
            System.out.println("Gagal membaca file teks.");
        }
    }

    private static void tampilkanFileSerial() {
        System.out.println("\nDaftar Buku (Serial)");

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(SERIAL_FILE))) {
            List<Buku> list = (List<Buku>) ois.readObject();

            for (Buku b : list) {
                b.tampilkanInfo();
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Gagal membaca file serial.");
        }
    }
}