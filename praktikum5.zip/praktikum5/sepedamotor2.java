package praktikum5;

public class sepedamotor2 extends kendaraanDarat {
    public String jenisMesin;

    public sepedamotor2(String nama, int kecepatan, int jumlahRoda, String jenisMesin) {
        super(nama, kecepatan, jumlahRoda);
        this.jenisMesin = jenisMesin;
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("=== Info Sepeda Motor (3-level) ===");
        super.tampilkanInfo();
        System.out.println("Jenis Mesin: " + jenisMesin);
    }
}
