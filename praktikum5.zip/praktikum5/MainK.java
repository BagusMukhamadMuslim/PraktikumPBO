package praktikum5;

public class MainK{
    public static void main(String[] args) {
        mobil mobil = new mobil("Toyota Avanza", 140, 4);
        sepedamotor motor = new sepedamotor("Yamaha Nmax", 120, "4-tak");

        System.out.println("== Output Praktikum ==");
        mobil.tampilkanInfo();
        System.out.println();

        motor.tampilkanInfo();
    }
}
