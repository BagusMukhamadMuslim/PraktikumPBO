package praktikum5;

public class anjing extends hewan {
    public anjing() {}

    public anjing(String nama) {
        super(nama, "Anjing");
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("=== Info Anjing ===");
        super.tampilkanInfo();
    }
}
