package praktikum5;

public class mobil extends kendaraan {
    public int jumlahPintu;

    public mobil() {}

    public mobil(String nama, int kecepatan, int jumlahPintu) {
        super(nama, kecepatan);
        this.jumlahPintu = jumlahPintu;
    }

    // overriding tampilkanInfo untuk menambah informasi spesifik mobil
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Jumlah Pintu: " + jumlahPintu);
    }

}
