package praktikum5;

public class sepedamotor extends kendaraan {
    public String jenisMesin;

    public sepedamotor() {}

    public sepedamotor(String nama, int kecepatan, String jenisMesin) {
        super(nama, kecepatan);
        this.jenisMesin = jenisMesin;
    }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Jenis Mesin: " + jenisMesin);
    }
}
