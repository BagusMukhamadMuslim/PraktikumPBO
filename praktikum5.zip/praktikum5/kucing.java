package praktikum5;

public class kucing extends hewan {
    public kucing() {}

    public kucing(String nama) {
        super(nama, "Kucing");
    }

    @Override
    public void tampilkanInfo() {
        System.out.println("=== Info Kucing ===");
        super.tampilkanInfo();
    }
}
