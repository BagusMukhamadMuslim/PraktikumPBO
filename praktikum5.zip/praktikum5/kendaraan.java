package praktikum5;

public class kendaraan {
    public String nama;
    public int kecepatan; // km/jam

    public kendaraan() {}

    public kendaraan(String nama, int kecepatan) {
        this.nama = nama;
        this.kecepatan = kecepatan;
    }

    public void tampilkanInfo() {
        System.out.println("=== Info Kendaraan ===");
        System.out.println("Nama Kendaraan: " + nama);
        System.out.println("Kecepatan: " + kecepatan + " km/jam");
    }
}
