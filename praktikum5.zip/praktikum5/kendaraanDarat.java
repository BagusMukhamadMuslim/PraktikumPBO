package praktikum5;

public class kendaraanDarat extends kendaraan {
    public int jumlahRoda;

    public kendaraanDarat() {}

    public kendaraanDarat(String nama, int kecepatan, int jumlahRoda) {
        super(nama, kecepatan);
        this.jumlahRoda = jumlahRoda;
    }

    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        System.out.println("Jumlah Roda: " + jumlahRoda);
    }
}
