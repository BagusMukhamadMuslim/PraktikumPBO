/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package responsi;

/**
 *
 * @author Acer
 */
public class Main {
    public static void main(String[] args) {
        // Produk
        produk produk1 = new elektronik("Laptop", 5500000, 2);
        produk1.tampilkanInfo();
        System.out.println();

        // Pegawai
        pegawai pegawai1 = new pegawaiTetap("Budi", 5000000, 1000000);
        pegawai1.tampilkanInfo();
        System.out.println();

        // Polimorfisme Produk
        produk produk2 = new makanan("Snack", 15000, "2023-12-30");
        produk2.tampilkanInfo();
        System.out.println();

        // Polimorfisme Pegawai
        pegawai pegawai2 = new pegawaiKontrak("Andi", 3000000, 12);
        pegawai2.tampilkanInfo();
    }
}

