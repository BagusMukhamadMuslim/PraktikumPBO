package praktikum3;

public class Main {
    public static void main(String[] args) {
        Hewan kucing = new Hewan("Nekomata", 2);
        kucing.suara();
        kucing.info();

        Hewan anjing = new Hewan("Cerberus", 3);
        anjing.berlari();
        anjing.info();
    }
}
