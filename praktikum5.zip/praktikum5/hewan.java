package praktikum5;

public class hewan {
    public String nama;
    public String jenis;

    public hewan() {}

    public hewan(String nama, String jenis) {
        this.nama = nama;
        this.jenis = jenis;
    }

    public void tampilkanInfo() {
        System.out.println("Nama: " + nama);
        System.out.println("Jenis: " + jenis);
    }
}
