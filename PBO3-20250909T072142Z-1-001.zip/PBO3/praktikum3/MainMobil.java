package praktikum3;

public class MainMobil {
    public static void main(String[] args) {
        Mobil mobil1 = new Mobil("Toyota", "Avanza", 2020, "Hitam");
        Mobil mobil2 = new Mobil("Honda", "Civic", 2022, "Putih");

        mobil1.startEngine();
        mobil1.displayInfo();

        mobil2.startEngine();
        mobil2.displayInfo();

        // Mengubah warna mobil1
        mobil1.setWarna("Merah");
        System.out.println("Setelah diubah warna");
        mobil1.displayInfo();
    }
}
