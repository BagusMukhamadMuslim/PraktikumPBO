package praktikum5;

public class MainHewan {
    public static void main(String[] args) {
        kucing kitty = new kucing("Kitty");
        anjing buddy = new anjing("Buddy");

        kitty.tampilkanInfo();
        System.out.println();
        buddy.tampilkanInfo();
    }
}
