package praktikum5;

public class MainK2 {
    public static void main(String[] args) {
        mobil2 avanza = new mobil2("Avanza", 140, 4, 5);
        sepedamotor2 nmax = new sepedamotor2("Nmax", 120, 2, "4-tak");

        avanza.tampilkanInfo();
        System.out.println();
        nmax.tampilkanInfo();
    }
}
